using Microsoft.EntityFrameworkCore;
using System;
using System.Windows.Forms;
using System.Linq;
namespace Employee_Management_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "" || textBox2.Text == "" || textBox4.Text == ""  || comboBox1.SelectedIndex == -1  )
                {
                    MessageBox.Show("Please Fill all the Required Fields", "Reminder", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                if(textBox3.Text.Length!=13||textBox3.Text=="")
                {
                    MessageBox.Show("Enter Valid CNIC Number","Valid Entry",MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                if (!Double.TryParse(textBox5.Text, out double value))
                {
                    MessageBox.Show("Salary should be numbers only", "Reminder", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                if (dateTimePicker1.Value.Date > DateTime.Now.Date)
                {
                    MessageBox.Show("Please Select a Date of Past", "Reminder", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                Employee employee = new Employee
                {
                    Name = textBox1.Text,
                    FatherName = textBox2.Text,
                    CNIC = textBox3.Text,
                    Designation = textBox4.Text,
                    Salary = Convert.ToDouble(textBox5.Text),
                    Department = comboBox1.SelectedItem.ToString(),
                    HireDate = dateTimePicker1.Value.Date,

                };
                EmployeeContext db = new EmployeeContext();
                db.Employees.Add(employee);
                db.SaveChanges();

                MessageBox.Show("Record Inserted Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "")
                {
                    MessageBox.Show("Please Enter Name to Validate", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" ||  comboBox1.SelectedIndex == -1 || dateTimePicker1.Value.Date > DateTime.Now.Date)
                {
                    MessageBox.Show("Please Fill all the Required Fields", "Reminder", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                if(!Double.TryParse(textBox5.Text, out double value))
                {
                    MessageBox.Show("Salary should be numbers only","Reminder",MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                string nameToFind = textBox1.Text;
                using (var db = new EmployeeContext())
                {
                    Employee employeeToUpdate = db.Employees.FirstOrDefault(e => e.Name == nameToFind);

                    if (employeeToUpdate != null)
                    {
                        employeeToUpdate.Name = nameToFind;
                        employeeToUpdate.FatherName = textBox2.Text;
                        employeeToUpdate.CNIC = textBox3.Text;
                        employeeToUpdate.Designation = textBox4.Text;
                        employeeToUpdate.Salary = Convert.ToDouble(textBox5.Text);
                        employeeToUpdate.Department = comboBox1.SelectedItem.ToString();
                        employeeToUpdate.HireDate = dateTimePicker1.Value.Date;

                        db.SaveChanges();

                        MessageBox.Show("Updation Performed Successfully", "Informatiom", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                    else
                    {
                        MessageBox.Show("Unable To Find Entered Name,Try Using Other Names", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {


                string nameToFind = textBox1.Text;

                if (nameToFind == "")
                {
                    MessageBox.Show("Please Enter Name to Validate", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var confirmresult = MessageBox.Show("Are you sure to delete the Employee?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (confirmresult == DialogResult.No)
                {
                    return;
                }

                using (var db = new EmployeeContext())
                {
                    Employee employeeToDelete = db.Employees.FirstOrDefault(e => e.Name == nameToFind);

                    if (employeeToDelete != null)
                    {
                        db.Employees.Remove(employeeToDelete);

                        db.SaveChanges();

                        MessageBox.Show("Employee Deleted Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    else
                    {
                        MessageBox.Show("No Employee is found by this Name", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            EmployeeContext db=new EmployeeContext();
            dataGridView1.DataSource=db.Employees.ToList();
        }
    }
}
